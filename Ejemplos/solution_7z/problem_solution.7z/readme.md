# Título del problema

Resultado del análisis (qué debe hacer el sistema)

**Ejemplo de entrada**:

```
```

**Ejemplo de salida**:

```
```
