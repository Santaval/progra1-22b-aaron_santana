# procedure main()
def main():
    """ Start program execution """
    # Copy your algorithm. Convert it to comments.
    # Implement each step. Apply good programming practices.

main()
